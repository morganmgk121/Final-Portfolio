	<div class="bottom-wgt-area">
		<div class="wrap group">
			<div class="btm-wrap">
				<?php dynamic_sidebar('footer-widgets'); ?>
			</div> <!-- .btm-wrap --> 
		</div> <!-- .wrap -->
	</div> <!-- .bottom-wgt-area -->

	<footer id="footer">
		<div class="wrap group">
			<span class="copy">
				<?php echo ci_footer(); ?>
			</span>
		</div>
	</footer>

<?php wp_footer(); ?>

</body>
</html>
